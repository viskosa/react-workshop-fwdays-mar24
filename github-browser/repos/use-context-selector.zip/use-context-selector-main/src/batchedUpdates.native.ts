/* eslint-disable */
// @ts-ignore
export { unstable_batchedUpdates as batchedUpdates } from 'react-native';
