// eslint-disable-next-line
export { unstable_batchedUpdates as batchedUpdates } from 'react-dom';
